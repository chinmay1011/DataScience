import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class ResetDBDemo {

	public static void main(String[] args) {
		String driver="org.apache.derby.jdbc.ClientDriver";
		String url="jdbc:derby://localhost:1527/MyDerbyDB;create=true";
		Connection con = null;
		
		try {
			System.out.println("Loading DB drivers");
			Class.forName(driver);
			System.out.println("DB drivers loaded");
			
			System.out.println("Establishing DB connection");
			con = DriverManager.getConnection(url);
			System.out.println("DB connection established");
			
			Statement stmt = con.createStatement();
			stmt.executeUpdate("drop table employee");
			System.out.println("Employee table dropped.");
			con.commit();
		}  catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
