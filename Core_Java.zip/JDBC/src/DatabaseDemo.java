import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.derby.tools.sysinfo;

public class DatabaseDemo {

	static PreparedStatement ps;
	static Connection con;
	static Statement stmt;
	
	static {
		String driver="org.apache.derby.jdbc.ClientDriver";
		String url="jdbc:derby://localhost:1527/MyDerbyDB;create=true";		
		System.out.println("Loading DB drivers");
		
			try {
				Class.forName(driver);
			} catch (ClassNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		
		System.out.println("DB drivers loaded");
		
		System.out.println("Establishing DB connection");
		try {
			con = DriverManager.getConnection(url);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("DB connection established");
		try {
			stmt = con.createStatement();
			stmt.executeUpdate("create table Employee(id varchar(20), name varchar(40), dept varchar(40))");
		} catch (SQLException e) {
			System.out.println("Employee table already exist.");
		}
		
	}

	public static void main(String[] args) {
			while(true) {
			System.out.println("Enter your choice:");
			System.out.println("1. Insert into Employee");
			System.out.println("2. Display Employee");
			System.out.println("3. Exit");
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			try {
				switch(Integer.parseInt(br.readLine())) {
				case 1: {
					System.out.println("Enter id:");
					String id = br.readLine();
					System.out.println("Enter name:");
					String name = br.readLine();
					System.out.println("Enter department:");
					String dept = br.readLine();
					ps = con.prepareStatement("insert into Employee values(?,?,?)");
					ps.setString(1, id);
					ps.setString(2, name);
					ps.setString(3,  dept);
					int rows = ps.executeUpdate();
					System.out.println("Number of rows inserted: "+rows);
					System.out.println();
					break;
				}
				case 2:{
					System.out.println();
					ResultSet rs = stmt.executeQuery("select * from Employee");
					System.out.println("ID   |    NAME    |    Department");
					while(rs.next()) {
						System.out.println(rs.getString(1)+" | "+rs.getString(2)+" | "+rs.getString(3));
					}
					System.out.println();
					break;
				}
				case 3:{
					System.out.println("Program Exited.");
					System.exit(0);
				}
				default:{
					System.out.println("Please select correct choice..!!");
				}
				}
			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
