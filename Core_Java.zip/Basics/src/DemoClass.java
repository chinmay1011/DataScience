import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class DemoClass {

	public static void main(String[] args) throws IOException {
		
		/*SingletonExp singleton = SingletonExp.getInstance();
		singleton.display();*/
		
		/*FileInputStream fin = new FileInputStream("test.txt");
		FileOutputStream fout = new FileOutputStream("test2.txt");
		Scanner scanner = new Scanner(new InputStreamReader(System.in));
		String dir = "tmp/tmp1/etc";
		File file = new File(dir);
		File file1 = new File("tmp");
		
		try {
		char c;
		int in;
			Class.forName("oracle.jdbc.driver.OracleDriver");
			//Accepting input from user and writing it to the file
			 System.out.println("Enter character to write to the file...q to exit");
			 do {
				c = scanner.next().charAt(0);
				System.out.println(c);
				fout.write(c);
			}while(c!='q');
		
		
			 //Copying a content of a file to another file
			 while(fin.available()!=0) {
				
				fout.write(fin.read());
			}
		
			if(!file.exists()) {
				boolean flag = file.mkdirs();
				if(flag) {
					System.out.println("Directory successfully created.");
					String[] dirStr = file1.list();
					for(String path:dirStr) {
						System.out.println("/"+path);
						new File(path).list();
						
					}
				}else {
					System.out.println("Creation of directory failed.");
				}
			}else {
				System.out.println("Directory already exists.");
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if(fin!=null) {
				fin.close();
			}
			if(fout!=null) {
				fout.close();
			}
		}*/
		
		
		//Inner Classes
		/*OuterDemo outer = new OuterDemo();
		OuterDemo.InnerDemo inner = outer. new InnerDemo();
		OuterDemo.StaticInnerDemo staticInner = new OuterDemo.StaticInnerDemo();
		
		AnonymousInnerClass anonymous = new AnonymousInnerClass(){
			@Override
			void display() {
				// TODO Auto-generated method stub
				System.out.println("This is anonymous inner class.");
			}
		};
		
		outer.display();
		inner.display();
		staticInner.display();
		anonymous.display();*/
		
		
	}

}
