package Collections;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Vector;

public class CollectionDemo {

	public static void main(String[] args) {
		//VectorDemo.display();
		//StackDemo.display();
		//ListDemo.display();
		//SetDemo.display();
		MapDemo.display();
		//ComparableComparatorDemo.display();
		
	}

}
