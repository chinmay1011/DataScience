package Collections;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;


public class ListDemo {

	public static void display() {
		System.out.println("ArrayList Demo");
		System.out.println("-----------------------");
		ArrayList<String> al=new ArrayList<String>(5);
		System.out.println("Adding 'A''B''B''C''D''E' Element");
		al.add("D");
		al.add("B");
		al.add("C");
		al.add("F");
		al.add("D");
		al.add("A");
		System.out.println("Size of ArrayList: "+al.size());
		Iterator<String> it=al.iterator();
		System.out.println("Display ArrayList using Iterator");
		while(it.hasNext()) {
			System.out.println(it.next());
		}
		System.out.println("Display ArrayList using for-each");
		for(String a:al) {
			System.out.println(a);
		}
		System.out.println("Searching for 'B' Element...");
		if(al.contains("B"))
			System.out.print("Element 'B' found at "+al.indexOf("B"));
		else
			System.out.print("Element 'B' not found. ");
		System.out.println();
		System.out.println("Element at postion 3: "+al.get(3));
		Collections.sort(al);
		System.out.println("ArrayList is sorted");
		System.out.println("Display ArrayList using for-each");
		for(String a:al) {
			System.out.println(a);
		}
		System.out.println("-----------------------");
		
		
		System.out.println("LinkedList Demo");
		System.out.println("-----------------------");
		LinkedList<String> ll=new LinkedList<String>();
		System.out.println("Adding 'Akshay''Bholo''Bholo''Chandan' Element");
		ll.add("Chandan");
		ll.add("Bholo");
		ll.add("Bholo");
		ll.add("Akshay");
		System.out.println("Size of LinkedList: "+ll.size());
		Iterator<String> itr=ll.iterator();
		System.out.println("Display LinkedList using Iterator");
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		System.out.println("Display LinkedList using for-each");
		for(String a:ll) {
			System.out.println(a);
		}
		System.out.println("Searching for 'Bholo' Element...");
		if(ll.contains("Bholo"))
			System.out.print("Element 'Bholo' found at "+ll.indexOf("Bholo"));
		else
			System.out.print("Element 'Bholo' not found. ");
		System.out.println();
		System.out.println("Element at postion 3: "+ll.get(3));
		System.out.println("Removing the element at 2 "+ll.remove(2));
		System.out.println("Display LinkedList using for-each");
		for(String a:ll) {
			System.out.println(a);
		}
		
		Collections.sort(ll);
		System.out.println("LinkedList is sorted");
		System.out.println("Display LinkedList using for-each");
		for(String a:ll) {
			System.out.println(a);
		}
		System.out.println("-----------------------");
		
	}

}
