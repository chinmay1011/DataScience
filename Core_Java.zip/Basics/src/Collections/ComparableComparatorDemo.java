package Collections;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class ComparableComparatorDemo {

	public static void display() {
		ArrayList<Student> al=new ArrayList<Student>();
		al.add(new Student(3, "Chinmay", 26));
		al.add(new Student(2,"Prateek", 28));
		al.add(new Student(1, "Shrirang", 27));
		System.out.println("Before Sorting using Comparable");
		Iterator<Student> it=al.iterator();
		while(it.hasNext()) {
			it.next().display();
		}
		System.out.println();
		System.out.println("After Sorting using Comparable RollNo");
		Collections.sort(al);
		Iterator<Student> itr=al.iterator();
		while(itr.hasNext()) {
			itr.next().display();
		}
		System.out.println();
		System.out.println("After Sorting using AgeComparator");
		Collections.sort(al,new AgeComparator());
		Iterator<Student> itr1=al.iterator();
		while(itr1.hasNext()) {
			itr1.next().display();
		}
		System.out.println();
		System.out.println("After Sorting using NameComparator");
		Collections.sort(al,new NameComparator());
		Iterator<Student> itr2=al.iterator();
		while(itr2.hasNext()) {
			itr2.next().display();
		}
	}

}
