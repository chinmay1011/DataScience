package Collections;
import java.util.Enumeration;
import java.util.Stack;

public class StackDemo {

	public static void display() {
		Stack<String> s=new Stack<String>();
		System.out.println("Stack Demo");
		System.out.println("**********************");
		System.out.println("Adding 'A''B''C' to stack");
		s.push("A");
		s.push("B");
		s.push("C");
		System.out.println("Display stack using enumeration");
		Enumeration e= s.elements();
		while(e.hasMoreElements()) {
			System.out.print(e.nextElement()+"-");
		}
		System.out.println();
		System.out.println("Element at the top of the stack: "+s.peek());
		System.out.println("Element at the bottom of the stack: "+s.firstElement());
		System.out.println("Display stack(LIFO)");
		while(!s.empty()) {
			System.out.print(s.pop()+"-");
		}
	}

}
