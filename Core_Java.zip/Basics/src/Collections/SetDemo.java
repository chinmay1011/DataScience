package Collections;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.*;


public class SetDemo {

	public static void display() {
		System.out.println("HashSet Demo");
		System.out.println("-----------------------");
		HashSet<String> hs=new HashSet<>();
		
		System.out.println("Adding 'Shri''Prateek' to HashSet");
		hs.add("Shri");
		hs.add("Prateek");
		ArrayList<String> al=new ArrayList<String>();
		al.add("Shefali");
		al.add("Anshika");
		System.out.println("Adding ArrayList['Shefali''Anshika'] to HashSet");
		hs.addAll(al);
		System.out.println("Display HashSet using Iterator : Doesn't maintain insertion order");
		Iterator it=hs.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
		System.out.println("Display HashSet using for-each");
		for(String s:hs) {
			System.out.println(s);
		}
		System.out.println("Searching for Shri");
		if(hs.contains("Shri"))
			System.out.println("Shri found");
		else
			System.out.println("Shri not found");
		
		System.out.println("Trying to add duplicate element 'Prateek'");
		hs.add("Prateek");
		System.out.println("Display HashSet using for-each");
		for(String s:hs) {
			System.out.println(s);
		}
		System.out.println("-----------------------");
		
		
		System.out.println("LinkedHashSet Demo");
		System.out.println("-----------------------");
		LinkedHashSet<String> lhs=new LinkedHashSet<String>();
		System.out.println("Adding 'Shri''Prateek' to LinkedHashSet");
		lhs.add("Shri");
		lhs.add("Prateek");
		ArrayList<String> al1=new ArrayList<String>();
		al1.add("Shefali");
		al1.add("Anshika");
		System.out.println("Adding ArrayList['Shefali''Anshika'] to LinkedHashSet");
		lhs.addAll(al1);
		System.out.println("Display LinkedHashSet using Iterator : maintains insertion order");
		Iterator itr=lhs.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		System.out.println("Display LinkedHashSet using for-each");
		for(String s:lhs) {
			System.out.println(s);
		}
		System.out.println("Searching for Prateek");
		if(lhs.contains("Prateek"))
			System.out.println("Prateek found");
		else
			System.out.println("Prateek not found");
		
		System.out.println("Trying to add duplicate element 'Anshika'");
		lhs.add("Anshika");
		System.out.println("Display LinkedHashSet using for-each");
		for(String s:lhs) {
			System.out.println(s);
		}
		System.out.println("-----------------------");
		
		
		System.out.println("TreeSet Demo");
		System.out.println("-----------------------");
		TreeSet<String> ts=new TreeSet<String>();
		System.out.println("Adding 'Shri''Prateek' to TreeSet");
		ts.add("Shri");
		ts.add("Prateek");
		ArrayList<String> al2=new ArrayList<String>();
		al2.add("Shefali");
		al2.add("Anshika");
		System.out.println("Adding ArrayList['Shefali''Anshika'] to TreeSet");
		ts.addAll(al2);
		System.out.println("First Element "+ts.first());
		System.out.println("Last Element "+ts.last());
		System.out.println("Display TreeSet using Iterator : Maintains ascending order.");
		Iterator itr1=ts.iterator();
		while(itr1.hasNext()) {
			System.out.println(itr1.next());
		}
		System.out.println("Display TreeSet using for-each");
		for(String s:ts) {
			System.out.println(s);
		}
		System.out.println("Searching for Shefali");
		if(ts.contains("Shefali"))
			System.out.println("Shefali found");
		else
			System.out.println("Shefali not found");
		
		System.out.println("Trying to add duplicate element 'Shri'");
		ts.add("Shri");
		System.out.println("Display TreeSet using for-each");
		for(String s:ts) {
			System.out.println(s);
		}
		System.out.println("-----------------------");
	}

}
