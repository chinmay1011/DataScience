package Collections;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Set;
import java.util.TreeMap;

import javax.swing.text.html.HTMLDocument.Iterator;

public class MapDemo {

	public static void display() {
		System.out.println("HashMap Demo");
		System.out.println("----------------------");
		HashMap<Integer,String> hm=new HashMap<Integer,String>();
		System.out.println("Adding Elements to the HashMap");
		hm.put(Integer.valueOf(2), "Harshal");
		hm.put(Integer.valueOf(1), "Chinmay");
		hm.put(Integer.valueOf(3),"Chandan");
		System.out.println("Display HashMap key/value using keySet");
		Set<Integer> hs = hm.keySet();
		for(int i:hs) {
			System.out.println(i+" "+hm.get(i));
		}		
			
		System.out.println("Trying to add duplicate key 2");
		hm.put(2, "Shrirang");
		
		System.out.println("Display HashMap key/value using iterator");
		java.util.Iterator<Integer> itr= hs.iterator();
		while(itr.hasNext()) {
			int i=itr.next();
			System.out.println(i+" "+hm.get(i));
		}
		System.out.println("------------------------------");
		
		
		
		System.out.println("LinkedHashMap Demo");
		System.out.println("----------------------");
		LinkedHashMap<Integer,String> lhm=new LinkedHashMap<Integer,String>();
		System.out.println("Adding Elements to the LinkedHashMap");
		lhm.put(Integer.valueOf(2), "Harshal");
		lhm.put(Integer.valueOf(1), "Chinmay");
		lhm.put(Integer.valueOf(3),"Chandan");
		System.out.println("Display LinkedHashMap key/value using keySet : maintains insertion order");
		Set<Integer> hs1 = lhm.keySet();
		for(int i:hs1) {
			System.out.println(i+" "+lhm.get(i));
		}		
			
		System.out.println("Trying to add duplicate key 2");
		lhm.put(2, "Chandan");
		
		System.out.println("Display LinkedHashMap key/value using iterator");
		java.util.Iterator<Integer> itr1= hs1.iterator();
		while(itr1.hasNext()) {
			int i=itr1.next();
			System.out.println(i+" "+lhm.get(i));
		}
		System.out.println("------------------------------");

		
		
		System.out.println("TreeMap Demo");
		System.out.println("----------------------");
		TreeMap<Integer,String> tm=new TreeMap<Integer,String>();
		System.out.println("Adding Elements to the TreeMap");
		tm.put(Integer.valueOf(2), "Shrirang");
		tm.put(Integer.valueOf(1), "Chinmay");
		tm.put(Integer.valueOf(3),"Chandan");
		System.out.println("Display TreeMap key/value using keySet : maintains ascending order");
		Set<Integer> hs2 = tm.keySet();
		for(int i:hs2) {
			System.out.println(i+" "+tm.get(i));
		}		
			
		System.out.println("Trying to add duplicate key 2");
		tm.put(2, "Chandan");
		
		System.out.println("Display TreeMap key/value using iterator");
		java.util.Iterator<Integer> itr2= hs2.iterator();
		while(itr2.hasNext()) {
			int i=itr2.next();
			System.out.println(i+" "+tm.get(i));
		}
		System.out.println("------------------------------");
	}

}
