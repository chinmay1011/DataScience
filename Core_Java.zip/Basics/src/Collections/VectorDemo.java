package Collections;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Vector;

public class VectorDemo {

	public static void display() {
		Vector<String> v = new Vector<String>();
		System.out.println("Vector Demo");
		System.out.println("**********************");
		System.out.println("Adding 'A' to vector");
		v.add("A");
		ArrayList<String> a = new ArrayList<String>();
		a.add("B");
		a.add("C");
		System.out.println("Adding ArrayList['B','C'] to vector");
		v.addAll(a);
		Enumeration e = v.elements();
		Iterator i = v.iterator();
	    System.out.println("Display Vector");
		while(e.hasMoreElements()) {
			System.out.print(e.nextElement()+"-");
		}
		System.out.println();
		System.out.println("Adding 'D' at position 3 to vector");
		v.add(3, "D");
		System.out.println("Adding ArrayList['B','C'] at position 2 to vector");
		v.addAll(2, a);
		Enumeration e1 = v.elements();
		System.out.println("Display Vector");
		while(e1.hasMoreElements()) {
			System.out.print(e1.nextElement()+"-");
		}
		System.out.println();
		ArrayList<String> b = new ArrayList<String>();
		b.add("B");
		b.add("B");
		System.out.println("Element at position 3 "+v.elementAt(3));
		System.out.println("If vector contains 'A':"+v.contains("A"));
		System.out.println("If vector contains ArrayList['B','B']:"+v.containsAll(b));
	}
}
