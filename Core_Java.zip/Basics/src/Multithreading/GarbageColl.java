package Multithreading;

public class GarbageColl {
	public void finalize() {
		System.out.println("Garbage collector invoked.");
	}
	public static void main(String[] args) {
		GarbageColl gc = new GarbageColl();
		gc=null;
		System.gc();
	}
	
}
