package Multithreading;

public class ThreadClassExample extends Thread{
	public ThreadClassExample(String name) {
		this.setName(name);
	}

	public void run(){
		for(int i=0;i<5;i++) {
			if(i==2) {
				System.out.println(this.getName()+" is yielded.");
				Thread.yield();
			}
			if(i==1) {
				System.out.println(this.getName()+" is sleeping.");
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			System.out.println(this.getName()+" is running on "+i);
		}
	}
}
