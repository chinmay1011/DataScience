package Multithreading;

import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ThreadDemo {

	public static void main(String[] args) {
		//By extending Thread class
		ThreadClassExample tc1 = new ThreadClassExample("Thread 1");
		ThreadClassExample tc2 = new ThreadClassExample("Thread 2");
		tc1.setPriority(1);
		tc2.setPriority(2);
		tc1.start();
		tc2.start();
		//By implementing Runnable interface
		/*Thread t1=new Thread(new RunnableExample("Thread 1"));
		Thread t2=new Thread(new RunnableExample("Thread 2"));
		Thread t3=new Thread(new RunnableExample("Thread 3"));
		
		t1.setPriority(1);
		t2.setPriority(5);
		t3.setPriority(10);
		t1.setDaemon(true);
		t1.start();
		t2.start();
		t3.start();*/
		
		//By using Thread pool
		/*ExecutorService es = Executors.newFixedThreadPool(5);
		es.execute(new RunnableExample("Thread 1"));
		es.execute(new RunnableExample("Thread 2"));
		es.execute(new RunnableExample("Thread 3"));
		es.execute(new RunnableExample("Thread 4"));
		es.execute(new RunnableExample("Thread 5"));
		es.execute(new RunnableExample("Thread 6"));
		es.execute(new RunnableExample("Thread 7"));
		es.execute(new RunnableExample("Thread 8"));
		es.execute(new RunnableExample("Thread 9"));
		es.execute(new RunnableExample("Thread 10"));	*/
		
		
		//ThreadGroup
		/*ThreadGroup tg1 = new ThreadGroup("Group 1");
		ThreadGroup tg2 = new ThreadGroup("Group 2");
		Thread t1=new Thread(tg1,new RunnableExample("Thread 1"));
		Thread t2=new Thread(tg1,new RunnableExample("Thread 2"));
		Thread t3=new Thread(tg1,new RunnableExample("Thread 3"));
		Thread t4=new Thread(tg2,new RunnableExample("Thread 4"));
		Thread t5=new Thread(tg2,new RunnableExample("Thread 5"));
		
		t1.start();
		t2.start();
		t3.start();
		t4.start();
		t5.start();
		System.out.println("Thread Group 1 active thread: "+tg1.activeCount());
		System.out.println("Thread Group 2 active thread: "+tg2.activeCount());*/
		
		
		//Synchronization
		/*SynchronizedClass synClass = new SynchronizedClass();
		
		Thread t1 = new Thread("Thread 1") {
			public void run() {
				synClass.printTable(5);
				//synClass.printTab(5);
				//SynchronizedClass.printTable1(5);
			}
		};
		Thread t2 = new Thread("Thread 2") {
			public void run() {
				synClass.printTable(100);
				//synClass.printTab(100);
				//SynchronizedClass.printTable1(100);
			}
		};
		
		t1.start();
		t2.start();*/
		
		
	}

}
