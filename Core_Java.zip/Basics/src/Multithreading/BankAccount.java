package Multithreading;

public class BankAccount  {
	int balance;
	
	public BankAccount(int balance) {
		this.balance=balance;
	}
	
	public void withdraw(int amount) {
		synchronized(this) {	
			System.out.println("Withdrawing "+amount+" from this account.");
			try {
				if(this.balance<amount) {
					throw new InsufficientFundException();					
				}				
				this.balance-=amount;		
				System.out.println("Amount "+amount+" withdrawn successfully."+" Current account balance is "+this.balance);
			}catch(InsufficientFundException ife) {
				System.out.println("Caught InsufficientFundException: "+ife.getMessage());
				try {
					wait();
					System.out.println("Withdrawal resumed.");
					this.balance-=amount;		
					System.out.println("Amount "+amount+" withdrawn successfully."+" Current account balance is "+this.balance);
				}catch(Exception e) {
				}
			}
		}	
	}
	
	public void deposit(int amount) {
		if(amount<0) {
			System.out.println("Invalid deposit amount");
		}else {
			synchronized(this) {
				System.out.println("Depositing "+amount+" to this account.");
				this.balance+=amount;
				notify();
				System.out.println("Amount "+amount+" deposited successfully."+" Current account balance is "+this.balance);
			}
		}
		
	}

}
