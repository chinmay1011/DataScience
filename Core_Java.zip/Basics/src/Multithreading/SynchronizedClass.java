package Multithreading;

public class SynchronizedClass {
	
	//synchronized method
	synchronized public void printTable(int n){
		for(int i=1;i<=10;i++) {
			System.out.println(Thread.currentThread().getName()+" "+n+"X"+i+"="+(n*i));
			}
		System.out.println(Thread.currentThread().getName()+" have ended.");
	}
	
	//synchronized block
	 public void printTab(int n){
		synchronized(this){
			for(int i=1;i<=10;i++) {
				System.out.println(Thread.currentThread().getName()+" "+n+"X"+i+"="+(n*i));
			}
			System.out.println(Thread.currentThread().getName()+" have ended.");
		}
	}
	 
	 
	//static synchronization
	synchronized public static void printTable1(int n){
		for(int i=1;i<=10;i++) {
			System.out.println(Thread.currentThread().getName()+" "+n+"X"+i+"="+(n*i));
		}
		System.out.println(Thread.currentThread().getName()+" have ended.");
	}

}
