package Multithreading;

public class RunnableExample implements Runnable{
	private String name;

	public RunnableExample(String name) {
		this.name=name;
	}
	
	@Override
	public void run() {
		for(int i=0;i<5;i++) {
			System.out.println(Thread.currentThread().getThreadGroup().getName()+" "+this.getName()+" is running on "+i);
			while(Thread.interrupted()) {
				System.out.println(Thread.currentThread().getThreadGroup().getName()+" "+this.getName()+" have paused.");
			}
		}
		System.out.println(Thread.currentThread().getThreadGroup().getName()+" "+this.getName()+" have ended.");
		
	}

	public String getName() {
		return name;
	}

	
}
