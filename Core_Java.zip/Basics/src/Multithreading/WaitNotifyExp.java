package Multithreading;

public class WaitNotifyExp {

	public static void main(String[] args) {
		BankAccount ba = new BankAccount(1000);
		Thread t1 = new Thread(){
			public void run() {
				ba.withdraw(5000);
			}
		};
		Thread t2 = new Thread() {
			public void run() {
				ba.deposit(10000);
			}
		};
		
		t1.start();
		t2.start();
	}

}
