package Multithreading;

public class InsufficientFundException extends Exception {
	private final String message = "We cannot process your request due to insufficient funds. Please try later.";

	
	public InsufficientFundException() {
		super();
		// TODO Auto-generated constructor stub
	}


	public String getMessage() {
		return message;
	}
}
