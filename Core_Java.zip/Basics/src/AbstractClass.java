public abstract class AbstractClass {
		
		private int a;
		
		public AbstractClass(int x) {
			Integer int1 = new Integer(1);
		}
}
