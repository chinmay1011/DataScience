import java.util.Arrays;

public class SingletonExp {
 private static SingletonExp instance= null;
 
 private SingletonExp() {
	 
 }
 
 public static SingletonExp getInstance() {
	 if(instance==null) {
		 instance = new SingletonExp();
	 }
	 return instance;
 }
 
 public void display() {
	 System.out.println("This is a singleton class.");
 }
}
