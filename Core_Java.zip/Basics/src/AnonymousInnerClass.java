
public abstract class AnonymousInnerClass {
	abstract void display();
}
