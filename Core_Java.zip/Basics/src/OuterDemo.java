
public class OuterDemo {
	
	public class InnerDemo{
		public void display() {
			System.out.println("This is Inner Class");
		}
	}
	
	public static class StaticInnerDemo{
		public void display() {
			System.out.println("This is Static Inner Class");
		}
	}
	
	public void display() {
		class MethodInnerDemo{
			public void display() {
				System.out.println("This is Method locked Inner Class");
			}
		}
		new MethodInnerDemo().display();
	}
}
