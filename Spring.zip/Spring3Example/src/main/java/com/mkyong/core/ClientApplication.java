package com.mkyong.core;

import org.aspectj.weaver.AnnotationAnnotationValue;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.mkyong.config.MessageConfig;

public class ClientApplication {
	public static void main(String args[]) {
		/*ApplicationContext context = new AnnotationConfigApplicationContext(MessageConfig.class);*/
		/*ApplicationContext context = new ClassPathXmlApplicationContext("SpringBeans.xml");
		MessageConsumer bean = (MessageConsumer) context.getBean("consumerBean");
		MessageConsumer bean1 = (MessageConsumer) context.getBean("consumerBean1");
		MessageConsumer bean2 = (MessageConsumer) context.getBean("consumerBean");
		bean.setMsg("Hello world");
		bean.processMessage();
		bean1.processMessage("Welcome to Spring", "Harshal");
		bean2.processMessage();*/
		
		/*Resource resource = new ClassPathResource("CustomerBean.xml");
		BeanFactory factory = new XmlBeanFactory(resource);*/
		 
		
		/*ApplicationContext context = new ClassPathXmlApplicationContext("CustomerBean.xml");		
		Customer custBean1 = (Customer) context.getBean("customerBean");
		Customer custBean2 = (Customer) context.getBean("customerBean1");
		
		System.out.println(custBean1);
		System.out.println(custBean2);*/
		
		/*ApplicationContext context = new ClassPathXmlApplicationContext("StudentBean.xml");	
		Student studentBean = (Student) context.getBean("student");
		
		System.out.println(studentBean);*/
		
		ApplicationContext context = new ClassPathXmlApplicationContext("CalculatorBean.xml");	
		DivideCalculate calculateBean = (DivideCalculate) context.getBean("calculatorBean");
		
		calculateBean.printX();
		calculateBean.printY();
		calculateBean.divide();
		
 	}
}
