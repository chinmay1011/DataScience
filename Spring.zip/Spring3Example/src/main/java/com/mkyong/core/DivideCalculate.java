package com.mkyong.core;

import org.springframework.beans.factory.annotation.Value;

public class DivideCalculate {
	
	private int x;
	private int y;
	
	public DivideCalculate() {
	}

	public DivideCalculate(int x, int y) {
		super();
		this.x = x;
		this.y = y;
	}

	public void printX() {
		System.out.println("X="+this.x);
	}
	
	public void printY() {
		System.out.println("Y="+this.y);
	}
	
	public boolean divide() {
		float a = this.x / this.y;
		System.out.println("X/Y="+a);
		return true;
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}
	
	
}
