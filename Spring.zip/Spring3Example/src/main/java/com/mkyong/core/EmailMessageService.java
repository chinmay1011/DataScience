package com.mkyong.core;

import java.util.Date;
import java.util.List;

public class EmailMessageService implements MessageService {
	String msg=null;
	String to=null;
	Date on;
	
	
	public void setOn(Date on) {
		this.on = on;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public void setTo(String to) {
		this.to = to;
	}

	public void sendMessage() {
		// TODO Auto-generated method stub
		System.out.println("Email: '"+this.msg+"' sent to "+this.to+" on "+this.on);
	}
	
	@Override
	public void sendMessage(String msg, String to) {
		// TODO Auto-generated method stub
		System.out.println("Email: '"+msg+"' sent to "+to+" on "+this.on);
	}

	@Override
	public void setTo(List to) {
		// TODO Auto-generated method stub
		
	}

}
