package com.mkyong.core;

import java.util.List;

public interface MessageService {
	public void sendMessage(String msg, String to);

	public void sendMessage();

	public void setMsg(String msg);

	public void setTo(List to);
}
