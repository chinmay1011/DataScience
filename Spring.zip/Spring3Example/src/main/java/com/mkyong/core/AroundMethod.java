package com.mkyong.core;

import java.lang.reflect.Method;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;


public class AroundMethod implements MethodInterceptor {

	@Override
	public Object invoke(MethodInvocation arg0) throws Throwable {
		System.out.println(arg0.getMethod().getName()+" Method invoked!!!");
		try {
			
			Object result = arg0.proceed();
			
			System.out.println(arg0.getMethod().getName()+" Method returned!!!");
			
			return result;
		}catch(ArithmeticException e) {
			System.out.println(e.getMessage()+" caught during the method execution!!!");
		}
		return null;
	}

	
}
