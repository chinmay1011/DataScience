package com.mkyong.core;

import java.util.Date;
import java.util.List;

public class SmsMessageService implements MessageService {
	String msg=null;
	List to;
	Date on;
	
	
	public void setOn(Date on) {
		this.on = on;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public void setTo(List to) {
		this.to = to;
	}
	
	public void sendMessage() {
		// TODO Auto-generated method stub
		System.out.println("SMS: '"+this.msg+"' sent to "+this.to+" on "+this.on);
	}
	
	@Override
	public void sendMessage(String msg, String to) {
		// TODO Auto-generated method stub
		System.out.println("SMS: '"+msg+"' sent to "+to+" on "+this.on);
	}


}
