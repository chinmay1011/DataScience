package com.mkyong.core;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

public class MessageConsumer {
	private MessageService msgService;
	
	
	public MessageConsumer() {
		super();
	}

	public MessageConsumer(MessageService msgService) {
		super();
		this.msgService = msgService;
	}
	
	public void setMsg(String msg) {
		this.getMsgService().setMsg(msg);
	}
	
	public void setMsgService(MessageService msgService) {
		this.msgService = msgService;
	}
	
	
	
	public MessageService getMsgService() {
		return msgService;
	}

	public void processMessage() {
		this.msgService.sendMessage();
	}

	public void processMessage(String msg, String to) {
		this.msgService.sendMessage(msg, to);
	}
}
