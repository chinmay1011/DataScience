package com.mkyong.core;

import org.springframework.aop.ThrowsAdvice;

public class AfterException implements ThrowsAdvice {
	public void afterThrowing(ArithmeticException e) throws Throwable  {
		System.out.println(e.getMessage()+" caught during the method execution!!!");
	}
}
