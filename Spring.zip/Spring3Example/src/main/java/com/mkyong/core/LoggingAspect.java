package com.mkyong.core;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

@Aspect
public class LoggingAspect {
	
	@Before("execution(* com.mkyong.core.DivideCalculate.divide())")
	public void logBefore(JoinPoint joinPoint) {
		System.out.println(joinPoint.getSignature().getName()+" Method invoked!!!");
	}
	
	@After("execution(* com.mkyong.core.DivideCalculate.divide())")
	public void logAfter(JoinPoint joinPoint) {
		System.out.println(joinPoint.getSignature().getName()+" Method executed!!!");
	}
	
	@AfterReturning(pointcut = "execution(* com.mkyong.core.DivideCalculate.divide())",
		      returning= "result")
	public void logAfterReturning(JoinPoint joinPoint, Object result) {
		System.out.println(joinPoint.getSignature().getName()+" Method returned "+result+"!!!");
	}
	
	@AfterThrowing(pointcut="execution(* com.mkyong.core.DivideCalculate.divide())",
			throwing="error")
	public void logAfterException(JoinPoint joinPoint, Throwable error) {
		System.out.println(joinPoint.getSignature().getName()+" Method throwing "+error.getMessage()+"!!!");
	}
	
	@Around("execution(* com.mkyong.core.DivideCalculate.*())")
	public void logAround(ProceedingJoinPoint joinPoint) throws Throwable{
		try {
			System.out.println(joinPoint.getSignature().getName()+" Method invoked!!!");
			joinPoint.proceed();
			System.out.println(joinPoint.getSignature().getName()+" Method executed!!!");
		} catch (Exception e) {
			System.out.println(joinPoint.getSignature().getName()+" Method throwing "+e.getMessage()+"!!!");
		}
	}
}
