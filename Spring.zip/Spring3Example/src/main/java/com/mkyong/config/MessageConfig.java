package com.mkyong.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import com.mkyong.core.EmailMessageService;
import com.mkyong.core.MessageConsumer;
import com.mkyong.core.MessageService;
import com.mkyong.core.SmsMessageService;

@Configuration
public class MessageConfig {
	
	@Bean(name="consumerBean")
	public MessageConsumer getMessageService() {
		return new MessageConsumer(new EmailMessageService());
	}
}
